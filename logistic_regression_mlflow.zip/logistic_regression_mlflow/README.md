## Train logistic regression model , log the model to mlflow and import MLFlow model to BentoML for serving.
python train.py

## Start the prediction service defined with BentoML in service.py, using the imported MLflow model:
bentoml serve service.py:svc

## Build Bento
bentoml build

## containerize BentoServier for deployment:
bentoml containerize logistic_regression_model_demo:latest

## Use Docker Container

docker-compose up



