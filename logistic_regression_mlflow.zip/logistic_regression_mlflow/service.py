import bentoml

mnist_runner = bentoml.mlflow.get("logistic_regression_model:latest").to_runner()

svc = bentoml.Service("logistic_regression_model_demo", runners=[mnist_runner])

input_spec = bentoml.io.NumpyNdarray(
    dtype="float64",  # You can adjust the dtype as needed
    shape=[-1, 4],    # Since the Iris dataset has 4 features
    enforce_dtype=True,
)

@svc.api(input=input_spec, output=bentoml.io.NumpyNdarray())
async def predict(input_arr):
    return await mnist_runner.predict.async_run(input_arr)
